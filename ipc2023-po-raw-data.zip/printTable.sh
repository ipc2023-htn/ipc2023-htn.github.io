


echo "Satisfing Track - PO"
(
cat instance.count | awk '{print $2}' | awk -F- 'BEGIN{printf("planner,track,total")}NF==1{printf(",%s",substr($1,1,5))} NF > 1{printf(",%s%s",substr($1,1,3),substr($2,1,2))} END{printf("\n")}'
cat .satisficing | awk -F, '{printf($1); s=0; for (i=2; i<=NF;i++) {s+=$i }; printf(",%.5f",s) ; for (i=2; i<=NF;i++) {if ($i == 0) printf(",\033[31m0.00\033[0m"); else printf(",%.2f",$i) }; printf("\n") }' | sort -t, -k2 -g -r | while read L ; do
DO=$(singularity inspect $(ls sifs-*/$(echo $L | cut -d, -f 1) | tail -n 1) | grep Track-PO-satisficing | cut -d' ' -f 2)
	echo $(echo $L | cut -d, -f 1)","$DO","$(echo -e $L | cut -d, -f 2-)
done) | sed 's/.sif//g' | column -t -s,

echo -e "\n\n\n\n\nAgile Track - PO"
(
cat instance.count | awk '{print $2}' | awk -F- 'BEGIN{printf("planner,track,total")}NF==1{printf(",%s",substr($1,1,5))} NF > 1{printf(",%s%s",substr($1,1,3),substr($2,1,2))} END{printf("\n")}'
cat .agile | awk -F, '{printf($1); s=0; for (i=2; i<=NF;i++) {s+=$i }; printf(",%.5f",s) ; for (i=2; i<=NF;i++) {if ($i == 0) printf(",\033[31m0.00\033[0m"); else printf(",%.2f",$i) }; printf("\n") }' | sort -t, -k2 -g -r | while read L ; do
	DO=$(singularity inspect $(ls sifs-*/$(echo $L | cut -d, -f 1) | head -n 1) | grep Track-PO-agile | cut -d' ' -f 2)
	echo $(echo $L | cut -d, -f 1)","$DO","$(echo $L | cut -d, -f 2-)
done) | sed 's/.sif//g'| column -t -s,



echo -e "\n\n\n\n\nOptimal Track - PO"
(
cat instance.count | awk '{print $2}' | awk -F- 'BEGIN{printf("planner,track,total")}NF==1{printf(",%s",substr($1,1,5))} NF > 1{printf(",%s%s",substr($1,1,3),substr($2,1,2))} END{printf("\n")}'
cat .optimal | awk -F, '{printf($1); s=0; f=0; for (i=3; i<=NF;i+=2) {j=i-1; if ($j != "T") f = 1; s+=$i }; if (f == 1) printf(",F") ; else printf(",%.5f",s); for (i=3; i<=NF;i+=2) {j=i-1; if ($j != "T") printf(",F"); else {if ($i == 0) printf(",\033[31m0.00\033[0m"); else printf(",%.2f",$i)} }; printf("\n") }' | sort -t, -k2 -g -r | while read L ; do
	DO=$(singularity inspect $(ls sifs-*/$(echo $L | cut -d, -f 1) | head -n 1) | grep Track-PO-optimal | cut -d' ' -f 2)
	echo $(echo $L | cut -d, -f 1)","$DO","$(echo $L | cut -d, -f 2-)
done) | sed 's/.sif//g'| column -t -s,

