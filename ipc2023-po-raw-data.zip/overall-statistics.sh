
RUN=run009
INSTOFFSET=0

echo "Extracting (potentially) found plans"
cd $RUN
grep "==>" $(find . | grep "/planner.out$") | cut -d'/' -f 2 | sed 's/-rundir/.time/g' > ../$RUN.planFound
echo "Extracting verification started"
grep "Mode: plan verification" -l *time > ../$RUN.verificationStarted

echo "Extracting successful verification results"
grep "Plan verification result: true" -l $(cat ../$RUN.verificationStarted) > ../$RUN.verificationTrue
echo "Extracting failed verification results"
grep "Plan verification result: false" -l $(cat ../$RUN.verificationStarted) > ../$RUN.verificationFalse
echo "Extracting no verification results"
grep -L "Plan verification result:" $(cat ../$RUN.verificationStarted) > ../$RUN.verificationAborted
cd ..


echo Analysing aborted verifications
cat $RUN.verificationAborted | while read F ; do if grep -q "No plan provided" $RUN/$F ; then echo $F ; fi ; done > $RUN.noPlanProvided
cat $RUN.verificationAborted | while read F ; do if grep -q "Two primitive task have the same id:" $RUN/$F ; then echo $F ; fi ; done > $RUN.verificationError

echo "True       : " $(cat $RUN.verificationTrue | wc -l)
echo "False      : " $(cat $RUN.verificationFalse | wc -l)
echo "No Plan    : " $(cat $RUN.noPlanProvided | wc -l)
echo "False (Err): " $(cat $RUN.verificationError | wc -l)
echo "Unexplained: " $(comm -23 <(sort $RUN.verificationAborted) <(sort $RUN.noPlanProvided $RUN.verificationError) | wc -l)
comm -23 <(sort $RUN.verificationAborted) <(sort $RUN.noPlanProvided $RUN.verificationError)

#### for debugging: determine instances with actually failed verification
#comm -23 <(sort run001.verificationAborted) <(sort run001.noPlanProvided run001.verificationError) | while read F ; do tail -n3 run001/$F ; done

comm -23 <(sort $RUN.planFound) <(sort $RUN.noPlanProvided $RUN.verificationError $RUN.verificationFalse) > $RUN.accepted

echo Extracting Statistics
bash extractStatistics.sh $RUN > $RUN.evaldata 
echo Printing Table Data
#bash printStatistics.sh

#bash printTable.sh
