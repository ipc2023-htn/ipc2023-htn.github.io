
cat *.evaldata | grep -v UNSOL | awk 'NR!=1{if (!($3 in a)){a[$3] = $4} else if (a[$3] > $4){a[$3] = $4}} END{for (i in a){print i, a[i]}}' | sort > instance.plans


WRITE=T

if [ $WRITE == "T" ] ; then
	rm -f .coverage
	rm -f .agile
	rm -f .satisficing
	rm -f .optimal
	touch .coverage
	touch .agile
	touch .satisficing
	touch .optimal
fi

cat run001.evaldata | awk '$5 <= 1800 {print} $5 > 1800 && $5 <= 1805 {print $1, $2, $3, $4, 1800, 0} $5 > 1805 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run001.evaldata.intime
cat run002.evaldata | awk '$5 <= 1800 {print} $5 > 1800 && $5 <= 1805 {print $1, $2, $3, $4, 1800, 0} $5 > 1805 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run002.evaldata.intime
cat run003.evaldata | awk '$5 <= 1800 {print} $5 > 1800 && $5 <= 1805 {print $1, $2, $3, $4, 1800, 0} $5 > 1805 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run003.evaldata.intime
cat run004.evaldata | awk '$5 <= 1800 {print} $5 > 1800 && $5 <= 1805 {print $1, $2, $3, $4, 1800, 0} $5 > 1805 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run004.evaldata.intime
cat run005.evaldata | awk '$5 <= 1800 {print} $5 > 1800 && $5 <= 1805 {print $1, $2, $3, $4, 1800, 0} $5 > 1805 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run005.evaldata.intime
cat run006.evaldata | awk '$5 <= 1800 {print} $5 > 1800 && $5 <= 1805 {print $1, $2, $3, $4, 1800, 0} $5 > 1805 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run006.evaldata.intime
cat run007.evaldata | awk '$5 <= 1800 {print} $5 > 1800 && $5 <= 1805 {print $1, $2, $3, $4, 1800, 0} $5 > 1805 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run007.evaldata.intime
cat run008.evaldata | awk '$5 <= 1800 {print} $5 > 1800 && $5 <= 1805 {print $1, $2, $3, $4, 1800, 0} $5 > 1805 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run008.evaldata.intime
cat run009.evaldata | awk '$5 <= 1800 {print} $5 > 1800 && $5 <= 1805 {print $1, $2, $3, $4, 1800, 0} $5 > 1805 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run009.evaldata.intime
#cat run003.evaldata | awk '$5 <= 1800 {print} $5 > 1800 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run003.evaldata.intime
#cat run004.evaldata | awk '$5 <= 1800 {print} $5 > 1800 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run004.evaldata.intime
#cat run006.evaldata | awk '$5 <= 1800 {print} $5 > 1800 {print $1, $2, $3, "UNSOL UNSOL UNSOL"}' > run006.evaldata.intime

NUMPLAN=$(ls sifs-run*/* | cut -d/ -f2 | sort -u | wc -l)

CURPLAN=0
ls sifs-run*/* | cut -d/ -f2 | sort -u | while read P ; do
#echo lamda-to-agl-gbfs-ao.sif | while read P ; do
	CURPLAN=$((CURPLAN + 1))
	echo $P $CURPLAN of $NUMPLAN

	#continue

	if [ $WRITE == "T" ] ; then
		echo -n $P >> .coverage
		echo -n $P >> .agile
		echo -n $P >> .satisficing
		echo -n $P >> .optimal
	fi
	cat /home/behnkeg/ipc2023-po/instance.count | while read COUNT DOMAIN ; do
		#echo -e "\n\n\n\n"
		#echo $DOMAIN
		#grep $P" "$DOMAIN" " *evaldata | sed -e 's/run\([0-9]*\).evaldata[^:]*:/\1 /g' | tac | sort -k4 -g -u


		COVERAGE=$(grep $P" "$DOMAIN" " *evaldata.intime | sed -e 's/run\([0-9]*\).evaldata[^:]*:/\1 /g' | tac | sort -k4 -g -u | grep -v UNSOL | wc -l)
		RELCOVERAGE=$(awk 'BEGIN{print '$COVERAGE'/'$COUNT'}')
		AGL=$(grep $P" "$DOMAIN" " *evaldata.intime | sed -e 's/run\([0-9]*\).evaldata[^:]*:/\1 /g' | tac | sort -k4 -g -u | grep -v UNSOL | awk '{a+=$7} END{print a/'$COUNT'}')
		echo T > .tempo

		grep $P" "$DOMAIN" " *evaldata.intime | sed -e 's/run\([0-9]*\).evaldata[^:]*:/\1 /g' | tac | sort -k4 -g -u | grep -v UNSOL | while read X X X INST PLANLEN X X ; do
			#echo "INSTANCE" "XX"$(grep "^"$INST instance.plans)"XX" $PLANLEN
			if [ $(grep "^"$INST instance.plans | cut -d' ' -f 2) == 0 ] ; then
				if [ $PLANLEN == 0 ] ; then
					SATSCORE=1
				else
					SATSCORE=0
				fi
			else
				SATSCORE=$(grep "^"$INST instance.plans | awk '{print $2 / '$PLANLEN'}')
				#echo SS score $SATSCORE
				if [ $SATSCORE != 1 ]; then
					if [ $(cat .tempo) == "T" ] ; then
						echo F$INST > .tempo
					fi
				elif (( $(echo "$SATSCORE > 1" |bc -l) )); then
					if [ $(cat .tempo) == "T" ] ; then
						echo X$INST > .tempo
					fi
				fi
			fi
			echo $SATSCORE 
		done | awk 'BEGIN{a = 0} {a+=$1} END{print a/'$COUNT'}' > .temp
		#done #| awk 'BEGIN{a = 0} {print} {print "LINE", $1; a+=$1} END{print "END", a/'$COUNT'}' #> .temp

		SATSCORE=$(cat .temp)
		OPTIMAL=$(cat .tempo)
		if [ $WRITE == "T" ] ; then
			echo -n ","$COVERAGE >> .coverage
			echo -n ","$AGL >> .agile
			echo -n ","$SATSCORE >> .satisficing
			echo -n ","$OPTIMAL","$RELCOVERAGE >> .optimal
		fi
		#echo $COVERAGE $AGL $SATSCORE $OPTIMAL $RELCOVERAGE
		#exit 0
	done
    tail -n1 .satisficing	
	echo
	if [ $WRITE == "T" ] ; then
		echo -ne '\n' >> .coverage
		echo -ne '\n' >> .agile
		echo -ne '\n' >> .satisficing
		echo -ne '\n' >> .optimal
	fi
done
